<?php $__env->startSection('content'); ?>
  <div class="row no-container">
    <div class="col-md-12 pb-5">
      <?php echo $__env->make('inc.navdark', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> <br> <br> <br><br>

    </div>
  </div>
  <div class="row offset-md-1 no-container">

  </div>

<div class="row justify-content-center no-container">
  <div class="col-md-6">
    <?php if(session('error')): ?>
      <div class="card card-header">
        <?php echo $__env->make('inc.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
    <?php endif; ?>

    <div class="card">
      <div class="card-header bg-faded">
        <p class="font-weight-bold text-muted text-center display-5">Please Sign In</p>
      </div>
      <div class="card-body bg-light">
        <?php echo Form::open(['action' => 'CompanyController@getsignin', 'data-parsley-validate'=>'']); ?>


        <div class="col-sm-12 col-md-12">
          <div class="form-group">
            <a href="#" class="btn btn-primary btn-block font-weight-bold">LOG-IN WITH FACEBOOK</a>
            </div>
        </div>
        <div class="col-sm-12 col-md-12">
          <div class="form-group">
            <a href="#" class="btn btn-danger btn-block font-weight-bold">LOG-IN WITH GOOGLE+</a>
            </div>
        </div>
        <p class="text-center font-weight-bold text-secondary">OR</p>
        <div class="col-sm-12 col-md-12">
          <div class="form-group">
              
              <input class="form-control form-control-lg" name="email"required='' placeholder="Your email" type="text">
            </div>
        </div>
        <?php if($errors->has('email')): ?>
          <span class="help-block" style="color:red"><?php echo $errors->first('email'); ?></span>
        <?php endif; ?>

        <div class="col-sm-12 col-md-12">
          <div class="form-group">
              
              <input class="form-control form-control-lg" name="password" required='' placeholder="Password" type="password">
            </div>
        </div>
        <?php if($errors->has('password')): ?>
          <span class="help-block" style="color:red"><?php echo $errors->first('password'); ?></span>
        <?php endif; ?>

        <div class="col-sm-12 col-md-12">
          <div class="form-group">
              <?php echo Form::submit('Sign In', ['class' => 'btn btn-outline-primary btn-block']); ?>

          </div>
        </div>
        <?php echo Form::close(); ?>


        <div class="col-sm-12 col-md-12">
          <div class="form-group">
            <a href="/companysignup" class="btn btn-block btn-info">Not registered?? !!</a>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mastar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>