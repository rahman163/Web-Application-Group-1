<?php $__env->startSection('content'); ?>
  


      



  



  <div class="row no-container">
    <div class="col-md-12 pb-5">
      <?php echo $__env->make('inc.navdark', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> <br> <br> <br><br>

    </div>
  </div>
  <div class="row offset-md-1 no-container">

  </div>


<div class="row no-container justify-content-center">
<div class="col-md-10 align-content-center">
  <div class="table-responsive">
      <table class="table table-striped">
        <thead>
          <tr>
            <th>Car Number</th>
            <th>Customer's email</th>
            <th>pickup Date</th>
            <th>Release Date</th>
            <th>Pickup Address</th>
            <th>Pickup Time</th>
            <th>Action</th>
            <th>Action</th>


          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($order->carnumber); ?></td>
              <td><?php echo e($order->email); ?></td>
              <td><?php echo e($order->pickupdate); ?></td>
              <td><?php echo e($order->releasedate); ?></td>

              <td><?php echo e($order->pickupAddress); ?></td>
              <td><?php echo e($order->pickupTime); ?></td>
              <td> <a href="/bookorder/<?php echo e($order->carnumber); ?>/<?php echo e($order->email); ?>/<?php echo e($order->pickupdate); ?>/<?php echo e($order->releasedate); ?>" class="btn btn-sm btn-success">Confirm Order</a> </td>
              <td> <a href="/cancelorder/<?php echo e($order->carnumber); ?>/<?php echo e($order->email); ?>" class="btn btn-sm btn-danger">Cancel Order</a> </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </div>
</div>
</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mastar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>