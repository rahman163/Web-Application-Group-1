<?php $__env->startSection('content'); ?>

  


  <div class="row no-container">
    <div class="col-md-12 pb-5">
      <?php echo $__env->make('inc.navdark', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> <br> <br> <br><br>

    </div>
  </div>
  <div class="row offset-md-1no-container">

  </div>

<div class="row justify-content-center no-container">
  <div class="col-md-6">
    <div class="card">
      <div class="card-header bg-faded">
        <p class="font-weight-bold text-muted text-center display-5">Add new location</p>
      </div>
      <div class="card-body bg-light">
        <?php echo Form::open(['action' => ['CompanyController@postnewlocation',  $company->id, $company->companyname], 'data-parsley-validate'=>'']); ?>

      <?php if(session('success')): ?>
        <div class="col-sm-12 col-md-12">
          <div class="form-group">
            <a href="#" class="btn btn-primary btn-block font-weight-bold"><?php echo $__env->make('inc.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></a>
          </div>
        </div>
      <?php endif; ?>

        <div class="col-sm-12 col-md-12">
          <div class="form-group">
              
              <input class="form-control form-control-lg" name="from" required='' placeholder="From" type="text">
            </div>
        </div>
        <div class="col-sm-12 col-md-12">
          <div class="form-group">
              
              <input class="form-control form-control-lg" name="to" required='' placeholder="To" type="text">
            </div>
        </div>

        <div class="col-sm-12 col-md-12">
          <div class="form-group">
              
              <input class="form-control form-control-lg" name="cost" required='' placeholder="Location Cost" type="text">
            </div>
        </div>



        <div class="col-sm-12 col-md-12">
          <div class="form-group">
              <?php echo Form::submit('Add Location', ['class' => 'btn btn-outline-primary btn-block']); ?>

            </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mastar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>