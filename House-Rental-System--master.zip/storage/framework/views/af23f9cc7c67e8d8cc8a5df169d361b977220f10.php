<?php $__env->startSection('content'); ?>

  <div class="row no-container">
    <div class="col-md-12 pb-5">
      <?php echo $__env->make('inc.navdark', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
  </div>
  <div class="row offset-md-1 no-container">

  </div>

  <div class="row mt-5 no-container justify-content-center no-container">
   	 <div class="col-md-4 align-self-center">
     	 	<div class="container">

     	 		
          <h3 class="text-muted font-weight-bold">Dahboard</h3>
     	 	</div>


   	 </div>
     <div class="col-md-4 align-self-center ">

            <h3 class="heading mb-3"><?php echo e($company->companyname); ?></h3>
            <div class="container">
              <p class="location"><i class="fa fa-map-marker"></i> <?php echo e($company->location); ?>

              </p>
               <p class="block"><i class="fa fa-phone"></i><?php echo e($company->phoneNumber); ?></p>
               <p class="block"><i class="fa fa-envelope"></i> <?php echo e($company->email); ?></p>
            </div>
     </div>

   </div>
   <div class="row no-container justify-content-center  mt-5">
     <div class="col-md-8">
       <div class="row no-container justify-content-between">
        

         <div class="col-md-4 companyProfile">
           <a href="/addnewhouse/<?php echo e($company->id); ?>/<?php echo e($company->companyname); ?>" target="_blank">
           <div class="card">
             <div class="card-header">
               <h3 class="text-center text-muted">Add New House</h3>
             </div>
             <div class="card-body bg-danger">
               <h1 class="font-italic text-white">new house to directory</h1>
             </div>
           </div>
         </a>
         </div>
        
       </div>
       </div>
     </div>
   </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mastar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>