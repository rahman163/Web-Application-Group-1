<?php echo $__env->make('inc.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.mins.css')); ?>">
<script type="text/javascript" src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>

    <header id="home-section">
      <div class="dark-overlay">
        <div class="home-inner">
          <div class="container">
            <div class="row">
              <div class="col-lg-8 align-self-center">
                <h1 class="display-4 text-white">Build <strong>social profiles</strong> and gain revenue and <strong>profits</strong></h1>

                <a href="/companysign" target="_blank" class=" text-white btn btn-primary btn-md form-control-lg mt-3 mb-3" style="opacity:0.9">Login</a>
              </div>
              <div class="col-lg-4">
                <div class="card bg-primary text-center card-form">
                  <div class="card-body">
                    <h3 class="text-white">Rent A House</h3>
                    <?php if($error): ?>
                        <?php if($availableTypes->isEmpty()): ?>
                          <p class="text-danger font-weight-bold">
                            There is no Rental service currently available.
                          </p>

                        <?php else: ?>
                          <p class="text-danger font-weight-bold"><?php echo e($error); ?></p>


                        <p class="text-danger font-weight-bold">
                          Please try
                            <?php $__currentLoopData = $availableTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $types): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($types->type); ?>,
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </p>
                         <?php endif; ?>

                    <?php else: ?>
                      <p class="text-white">Let us know where your want to rent !!</p>
                    <?php endif; ?>
                    <form action= "searchcar" method="get" data-parsley-validate="">
                      <div class="form-group">
                        
                        <select class="form-control form-control-lg" name="from" required="">
                          <option value="">Start From </option>
                          <option value="">------------------------------------</option>

                          <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($location->from); ?>"><?php echo e($location->from); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                      <div class="form-group">
                        
                        <select class="form-control form-control-lg" name="to" required="">
                          <option value="">End to </option>
                          <option value="">------------------------------------</option>

                          <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option value="<?php echo e($location->to); ?>"><?php echo e($location->to); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                      <div class="form-group">
                        <select class="form-control form-control-lg" name="type" required="">
                          <option value="Condo">Villa</option>
                          <option value="Villa">Micro</option>
                          <option value="Duplex">Duplex</option>

                        </select>
                      </div>

                      <input type="submit" class="btn btn-outline-light btn-block">
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>










<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mastar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>