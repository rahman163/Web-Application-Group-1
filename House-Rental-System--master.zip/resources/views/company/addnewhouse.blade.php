
@extends('layouts.mastar')

@section('content')

  <div class="row no-container">
    <div class="col-md-12 pb-5">
      @include('inc.navdark') <br> <br> <br><br>

    </div>
  </div>
  <div class="row offset-md-1 no-container">

  </div>

<div class="row justify-content-center no-container">
  <div class="col-md-6">
    <div class="card">
      <div class="card-header bg-faded">
        <p class="font-weight-bold text-muted text-center display-5">Add new House to the directory</p>
      </div>
      <div class="card-body bg-light">
        {!! Form::open(['action' => ['CompanyController@postnewhouse',  $company->id, $company->companyname],'files'=>true, 'data-parsley-validate'=>'']) !!}
        @if (session('success'))
          <div class="col-sm-12 col-md-12">
            <div class="form-group">
              <a href="#" class="btn btn-primary btn-block font-weight-bold">@include('inc.messages')</a>
            </div>
          </div>
        @endif

        <div class="col-sm-12 col-md-12">
          <div class="form-group">
              <input class="form-control form-control-lg" name="houseaddress" required='' placeholder="House Address" type="text">
            </div>
        </div>
        <div class="col-sm-12 col-md-12">
          <div class="form-group">
              <select class="form-control" name="type">
                <option>Select House Type</option>
                <option value="Condo">Condo</option>
                <option value="Villa">Villa</option>
                <option value="Duplex">Duplex</option>

              </select>
            </div>
        </div>

        <div class="col-sm-12 col-md-12">
          <div class="form-group">
              <input class="form-control form-control-lg" name="cost" required='' placeholder="Cost" type="number">
            </div>
        </div>
        
        <div class="col-sm-12 col-md-12">
          <div class="form-group">
              <input class="form-control form-control-lg" name="houseimage" required='' placeholder="Image" type="file">
            </div>
        </div>
       

        <div class="col-sm-12 col-md-12">
          <div class="form-group">
              {!! Form::submit('Add House', ['class' => 'btn btn-outline-primary btn-block']) !!}
            </div>
        </div>
      </div>
    </div>
  </div>
</div>


@endsection
