<h1>your message</h1> <br>

<div class="">
  {{$messageBody}}
</div>

<h4>sent via {{$email}}</h4>
