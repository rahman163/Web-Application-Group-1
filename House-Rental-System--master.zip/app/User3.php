<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class User3 extends Model
{
  protected $table = 'user3';

}
